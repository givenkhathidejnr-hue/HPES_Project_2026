// =========================================================================
// File        : ALU.v
// Description : 16-bit Arithmetic and Logic Unit (ALU).
//               Implements all arithmetic and logic operations required by
//               the StarCore ISA. This is a purely combinational module —
//               it has no clock input and no internal state.
// =============================================================================

`timescale 1ns / 1ps
`include "../src/Parameter.v"

module ALU (
    input  [15:0] a,            // Operand A  — connected to GPR read data 1
    input  [15:0] b,            // Operand B  — connected to ALUSrc mux output
    input  [ 2:0] alu_control,  // Operation select — driven by ALU_Control unit
    output reg [15:0] result,   // Computed result  — fed to DataMemory and write-back mux
    output         zero         // Zero flag: asserted (1) when result == 16'd0
);

    // -------------------------------------------------------------------------
    // Implement the zero flag using a continuous assignment.
    // -------------------------------------------------------------------------

    // -------------------------------------------------------------------------
    // Implement the ALU operations using a combinational always block.
    // -------------------------------------------------------------------------
    

    // Zero flag
    assign zero = (result == 16'd0);

    // Combinational ALU logic
    always @(*) begin
        case (alu_control)
            3'b000: result = a + b;                          // ADD
            3'b001: result = a - b;                          // SUB
            3'b010: result = ~a;                             // INV
            3'b011: result = a << b[3:0];                    // SHL
            3'b100: result = a >> b[3:0];                    // SHR
            3'b101: result = a & b;                          // AND
            3'b110: result = a | b;                          // OR
            3'b111: result = (a < b) ? 16'd1 : 16'd0;       // SLT
            default: result = a + b;                        // Safe fallback
        endcase
    end

endmodule
