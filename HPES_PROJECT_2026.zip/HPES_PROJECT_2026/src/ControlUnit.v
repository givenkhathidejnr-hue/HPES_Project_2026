// =========================================================================
// File        : ControlUnit.v
// Description : Main Control Unit.
//               Decodes the 4-bit opcode from the fetched instruction and
//               asserts the full set of control signals that govern the
//               Datapath for the current clock cycle.
//               This is a purely combinational module.
// =============================================================================

`timescale 1ns / 1ps
`include "../src/Parameter.v"

module ControlUnit (
    input  [3:0] opcode,        // Instruction opcode [15:12] from Datapath

    // ALU control
    output reg [1:0] alu_op,    // Passed to ALU_Control: 10=mem, 01=branch, 00=R-type

    // PC control
    output reg       jump,      // Assert to select the jump target PC
    output reg       beq,       // Assert to enable branch-on-equal
    output reg       bne,       // Assert to enable branch-on-not-equal

    // Memory control
    output reg       mem_read,  // Assert to enable data memory read output
    output reg       mem_write, // Assert to write data memory on posedge clk

    // Datapath multiplexer selects
    output reg       alu_src,   // 0 = RS2 register value; 1 = sign-extended immediate
    output reg       reg_dst,   // 0 = instr[8:6] (I-type WS); 1 = instr[5:3] (R-type WS)
    output reg       mem_to_reg,// 0 = ALU result; 1 = data memory read data (for LD)
    output reg       reg_write  // Assert to write the register file on posedge clk
);

    // -------------------------------------------------------------------------
    // Implement the control unit using always @(*) and a case statement.
    // -------------------------------------------------------------------------
        always @(*) begin
        // -----------------------------------------------------------------
        // Default values (VERY IMPORTANT to avoid latches)
        // -----------------------------------------------------------------
        reg_dst    = 1'b0;
        alu_src    = 1'b0;
        mem_to_reg = 1'b0;
        reg_write  = 1'b0;
        mem_read   = 1'b0;
        mem_write  = 1'b0;
        beq        = 1'b0;
        bne        = 1'b0;
        alu_op     = 2'b00;
        jump       = 1'b0;

        // -----------------------------------------------------------------
        // Decode opcode
        // -----------------------------------------------------------------
        case (opcode)

            // -------------------- LD --------------------
            4'b0000: begin
                reg_dst    = 1'b0;
                alu_src    = 1'b1;
                mem_to_reg = 1'b1;
                reg_write  = 1'b1;
                mem_read   = 1'b1;
                alu_op     = 2'b10;
            end

            // -------------------- ST --------------------
            4'b0001: begin
                alu_src    = 1'b1;
                mem_write  = 1'b1;
                alu_op     = 2'b10;
            end

            // -------------------- R-type (ADD → SLT) --------------------
            4'b0010, 4'b0011, 4'b0100, 4'b0101,
            4'b0110, 4'b0111, 4'b1000, 4'b1001: begin
                reg_dst   = 1'b1;
                reg_write = 1'b1;
                alu_op    = 2'b00;
            end

            // -------------------- Reserved --------------------
            4'b1010: begin
                // Do nothing (safe defaults already set)
            end

            // -------------------- BEQ --------------------
            4'b1011: begin
                beq    = 1'b1;
                alu_op = 2'b01;
            end

            // -------------------- BNE --------------------
            4'b1100: begin
                bne    = 1'b1;
                alu_op = 2'b01;
            end

            // -------------------- JMP --------------------
            4'b1101: begin
                jump = 1'b1;
            end

            // -------------------- Default --------------------
            default: begin
                // Already safe
            end

        endcase
    end



endmodule
