// =========================================================================
// File        : ALU_Control.v
// Description : ALU Control Unit.
//               Maps the 2-bit ALUOp signal (from the Main Control Unit) and
//               the 4-bit instruction opcode to the 3-bit ALUcnt signal that
//               drives the ALU's operation select input.
//               This is a purely combinational module.
// =============================================================================

`timescale 1ns / 1ps
`include "../src/Parameter.v"

module ALU_Control (
    input  [1:0] ALUOp,         // From ControlUnit:
                                //   2'b10 = memory access (always ADD for address)
                                //   2'b01 = branch      (always SUB for comparison)
                                //   2'b00 = R-type      (decode from opcode)
    input  [3:0] Opcode,        // Instruction opcode field [15:12]
    output reg [2:0] ALU_Cnt    // To ALU alu_control input
);

    // -------------------------------------------------------------------------
    //  Concatenate ALUOp and Opcode into a single 6-bit control word so
    //       you can use a casex statement with don't-care bits.
    // -------------------------------------------------------------------------


    // Concatenate ALUOp and Opcode
    wire [5:0] control_in;
    assign control_in = {ALUOp, Opcode};

    // Combinational ALU control logic
    always @(*) begin
        casex (control_in)
            // Memory access (LD, ST) → always ADD
            6'b10xxxx: ALU_Cnt = 3'b000;

            // Branch (BEQ, BNE) → always SUB
            6'b01xxxx: ALU_Cnt = 3'b001;

            // R-type instructions (ALUOp = 00 → decode opcode)
            6'b000010: ALU_Cnt = 3'b000; // ADD
            6'b000011: ALU_Cnt = 3'b001; // SUB
            6'b000100: ALU_Cnt = 3'b010; // INV
            6'b000101: ALU_Cnt = 3'b011; // SHL
            6'b000110: ALU_Cnt = 3'b100; // SHR
            6'b000111: ALU_Cnt = 3'b101; // AND
            6'b001000: ALU_Cnt = 3'b110; // OR
            6'b001001: ALU_Cnt = 3'b111; // SLT

            // Default (safe fallback)
            default:   ALU_Cnt = 3'b000; // ADD
        endcase
    end





endmodule
