// =========================================================================
// File        : InstructionMemory.v
// Description : Instruction Memory (ROM).
//               16 words × 16 bits. Contents loaded at simulation start from
//               the binary file ./test/test.prog using $readmemb.
//               This is a purely combinational module — the instruction output
//               updates immediately when the PC changes. No clock input.
// =============================================================================

`timescale 1ns / 1ps
`include "../src/Parameter.v"

module InstructionMemory (
    input  [15:0] 	pc,           // Program Counter (byte address)
	input         	secure_mode,	// Whether the processor is in secured mode
    output [15:0] 	out_instruction   // Fetched 16-bit instruction word
);

    // -------------------------------------------------------------------------
    // Declare the instruction memory array.
    // -------------------------------------------------------------------------
    reg [`COL-1:0] memory [`ROW_I-1:0];
	
	// -------------------------------------------------------------------------
    // XOR Decryption Key
    // -------------------------------------------------------------------------
    localparam [15:0] XOR_KEY = 16'hA5A5;
	
	// -------------------------------------------------------------------------
    // ROM Address Calculation
    // Each instruction is 2 bytes wide.
    // -------------------------------------------------------------------------
    //assign rom_addr = pc[4:1];
	
	// -------------------------------------------------------------------------
    // Raw instruction fetched from ROM
    // -------------------------------------------------------------------------
    wire [15:0] raw_instruction;
	wire [15:0] decrypted_version;

    // -------------------------------------------------------------------------
    // Derive the word address from the byte-addressed PC.
    // -------------------------------------------------------------------------
    wire [3:0] rom_addr = pc[4:1];
	assign raw_instruction = memory[rom_addr];

    // -------------------------------------------------------------------------
    // Load the instruction memory contents from file at simulation start
    // -------------------------------------------------------------------------
    initial begin
        $readmemb(`RUN_PROG_FILE, memory, 0, 14);
    end


    // -------------------------------------------------------------------------
    // Secure-mode conditional decryption
    // -------------------------------------------------------------------------
	assign decrypted_version = raw_instruction ^ XOR_KEY;
    assign out_instruction =
        secure_mode ?
        (decrypted_version) :
        raw_instruction;


endmodule
