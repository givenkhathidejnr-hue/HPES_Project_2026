// =========================================================================
// File        : DataMemory.v
// Description : Data Memory (RAM).
//               8 words × 16 bits. Contents loaded at simulation start from
//               the binary file ./test/test.data using $readmemb.
//               Writes are synchronous (positive-edge clocked).
//               Reads are combinational and gated by the mem_read enable.
// =============================================================================

`timescale 1ns / 1ps
`include "../src/Parameter.v"

module DataMemory (
    input        clk,

    // Shared address bus (used for both reads and writes)
    input  [15:0] mem_access_addr,  // Byte address; only lower bits used for indexing

    // Write port
    input  [15:0] mem_write_data,   // Data to store
    input        mem_write_en,      // Assert to write on the next posedge clk

    // Read port
    input        mem_read,          // Assert to enable the read output
    output [15:0] mem_read_data     // Read result; 16'd0 when mem_read is de-asserted
);

    // -------------------------------------------------------------------------
    // Declare the data memory array.
    // -------------------------------------------------------------------------

    reg [`COL-1:0] memory [`ROW_D-1:0];


    // -------------------------------------------------------------------------
    // Derive the word address from mem_access_addr.
    // -------------------------------------------------------------------------

    wire [2:0] ram_addr = mem_access_addr[2:0];


    // -------------------------------------------------------------------------
    // Load the data memory from file at simulation start.
    // -------------------------------------------------------------------------

    integer log_fd;
    initial begin
        $readmemb("../test/test.data", memory, 0, 7);
    end

    // -------------------------------------------------------------------------
    // Implement the synchronous write port.
    // -------------------------------------------------------------------------

    always @(posedge clk) begin
        if (mem_write_en)
            memory[ram_addr] <= mem_write_data;
    end


    // -------------------------------------------------------------------------
    // Implement the combinational (gated) read port.
    // -------------------------------------------------------------------------

     assign mem_read_data = mem_read ? memory[ram_addr] : 16'd0;


endmodule
